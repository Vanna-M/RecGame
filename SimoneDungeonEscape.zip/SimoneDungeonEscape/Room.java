import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public abstract class Room extends JPanel{
    protected int _val, _villain;
    public int getVal(){
        return _val;
    }
    // gets int corresponding to villain
    /*
        0 = no villain
        1 = Dean
        2 = Big Evil
        3 = Disciplinary
    */
    public int getVillain(){
        return _villain;
    }
    public abstract void up();
    public abstract void down();
    public abstract void right();
    public abstract void left();
    public abstract void mouseClicked(int x, int y);

}
