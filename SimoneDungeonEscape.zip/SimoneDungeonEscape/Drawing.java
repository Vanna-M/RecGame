import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Drawing{

    // all of the villains will send in the picture at the given coors
    public static void dean(Graphics g, int x, int y){
        BufferedImage d = null; // declare image
        try {
            d = ImageIO.read(new File("Dean.png")); // here's the source
        }
        catch (IOException e) { // required
        }
        g.drawImage(d, x, y, null);
        // put image d on Graphics g at position x,y
        //we're not modifying him in-game, so ImageObserver is null
    }

    public static void frisk(Graphics g, int x, int y){
        BufferedImage img = null; // declare image
        try {
            img = ImageIO.read(new File("Frisk.png")); // here's the source
        }
        catch (IOException e) { // required
        }
        g.drawImage(img, x, y, null);
        // put image d on Graphics g at position x,y
        //we're not modifying him in-game, so ImageObserver is null
    }

    public static void talk(Graphics g, int x, int y, String message){
        g.drawString(message, x + 50, y - 30);
    }
}
